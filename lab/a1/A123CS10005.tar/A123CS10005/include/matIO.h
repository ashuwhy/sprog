#include <stdio.h>
#include <stdio.h>
#include "defs.h"

void readMatrix(Matrix* );
void printMatrix(Matrix );
#define ROWS 100
#define COLS 100

typedef struct{
    int arr[ROWS][COLS];
    int rows;
    int cols;
}Matrix;
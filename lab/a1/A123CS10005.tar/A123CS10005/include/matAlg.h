#include <stdio.h>
#include <stdio.h>
#include "matIO.h"

int addMatrix(Matrix , Matrix );
int subMatrix(Matrix , Matrix );
int multMatrix(Matrix , Matrix );
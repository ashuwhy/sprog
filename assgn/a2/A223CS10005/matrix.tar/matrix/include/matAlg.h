#include "defs.h"

int addMat(Matrix , Matrix);
int subMat(Matrix , Matrix);
int multMat(Matrix , Matrix);
void printMatrix(Matrix);

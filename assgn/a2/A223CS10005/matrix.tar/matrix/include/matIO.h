#include "defs.h"

void readMatrix(Matrix *);
void printMatrix(Matrix);
